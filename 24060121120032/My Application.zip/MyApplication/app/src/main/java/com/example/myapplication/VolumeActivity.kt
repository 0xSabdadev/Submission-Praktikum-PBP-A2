package com.example.myapplication

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.myapplication.ui.theme.MyApplicationTheme

class VolumeActivity : ComponentActivity(), View.OnClickListener {
    private lateinit var tvResult: TextView
    private lateinit var etWidth: EditText
    private lateinit var etHeight: EditText
    private lateinit var etLength: EditText
    private lateinit var btnCalculate: Button
    private lateinit var btnCalculate2: Button
    private lateinit var btnCalculate3: Button

    // State
    private val KEY_RESULT = "key_result"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                setContentView(R.layout.activity_volume)
                tvResult = findViewById(R.id.tv_result)
                etWidth = findViewById(R.id.et_width)
                etLength = findViewById(R.id.et_length)
                etHeight = findViewById(R.id.et_height)
                btnCalculate = findViewById(R.id.btn_calculate)
                btnCalculate2 = findViewById(R.id.btn_calculate2)
                btnCalculate3 = findViewById(R.id.btn_calculate3)

                btnCalculate.setOnClickListener(this)
                btnCalculate2.setOnClickListener(this)
                btnCalculate3.setOnClickListener(this)
            }
        }

        if (savedInstanceState != null) {
            val result = savedInstanceState.getString(KEY_RESULT)
            tvResult.text = result
        }
    }

    override fun onClick(view: View?) {
        if (view != null) {
            val inputLength: String = etLength.text.toString().trim()
            val inputWidth: String = etWidth.text.toString().trim()
            val inputHeight: String = etHeight.text.toString().trim()

            try {
                val length = inputLength.toDouble()
                val width = inputWidth.toDouble()
                val height = inputHeight.toDouble()

                when (view.id) {
                    R.id.btn_calculate -> {
                        // Hitung volume balok
                        val volume: Double = length * height * width
                        // Tampilkan hasil perhitungan di TextView -> tvResult
                        val resultText = "Volume: %s"
                        tvResult.text = String.format(resultText, volume.toString())
                    }
                    R.id.btn_calculate2 -> {
                        // Hitung luas permukaan balok
                        val luas: Double = 2 * (length * width + length * height + height * width)
                        // Tampilkan hasil perhitungan di TextView -> tvResult
                        val resultText = "Luas Permukaan: %s"
                        tvResult.text = String.format(resultText, luas.toString())
                    }
                    R.id.btn_calculate3 -> {
                        // Hitung keliling balok
                        val keliling: Double = 4 * (length + height + width)
                        // Tampilkan hasil perhitungan di TextView -> tvResult
                        val resultText = "Keliling: %s"
                        tvResult.text = String.format(resultText, keliling.toString())
                    }
                }
            } catch (e: NumberFormatException) {
                // Tangani kesalahan jika input tidak valid
                tvResult.text = "Input tidak valid"
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)

        val calculationResult = tvResult.text.toString()
        outState.putString(KEY_RESULT, calculationResult)
    }
}
